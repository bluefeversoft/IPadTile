//
//  GamePlayLayer.m
//  TileTutorial
//
//  Created by ScreenCast on 6/19/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import "GamePlayLayer.h"

#define kBOARDTOPLEFTX 160
#define kBOARDTOPLEFTY 32
#define kTILEBORDER 10
#define kTILEGAP 6
#define kTILEWIDTH 130

const int Cols[25] = {
    0,1,2,3,4,
    0,1,2,3,4,
    0,1,2,3,4,
    0,1,2,3,4,
    0,1,2,3,4    
};

const int Rows[25] = {
    0,0,0,0,0,
    1,1,1,1,1,
    2,2,2,2,2,
    3,3,3,3,3,
    4,4,4,4,4
};

@implementation GamePlayLayer

-(int)GetXCoordFromTileCol:(int)Col {
    return kBOARDTOPLEFTX + kTILEBORDER + ( (kTILEWIDTH + kTILEGAP) * Col );
}

-(int)GetYCoordFromTileRow:(int)Row {
    return kBOARDTOPLEFTY + kTILEBORDER + ( (kTILEWIDTH + kTILEGAP) * Row );    
}


-(id)init {
    
    self = [super init];
    
    if(self != nil) {
        
        
    }
    
    return self;
}


@end
