//
//  GamePlayLayer.m
//  TileTutorial
//
//  Created by ScreenCast on 6/19/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import "GamePlayLayer.h"

#define kBOARDBOTTOMLEFTX 160
#define kBOARDBOTTOMLEFTY 32
#define kTILEBORDER 10
#define kTILEGAP 6
#define kTILEWIDTH 130

#define kEMPTY 24

const int Cols[25] = {
    0,1,2,3,4,
    0,1,2,3,4,
    0,1,2,3,4,
    0,1,2,3,4,
    0,1,2,3,4    
};

const int Rows[25] = {
    0,0,0,0,0,
    1,1,1,1,1,
    2,2,2,2,2,
    3,3,3,3,3,
    4,4,4,4,4
};

@implementation GamePlayLayer

-(int)GetXCoordFromTileCol:(int)Col {
    return kBOARDBOTTOMLEFTX + kTILEBORDER + ( (kTILEWIDTH + kTILEGAP) * Col );
}

-(int)GetYCoordFromTileRow:(int)Row {
    return kBOARDBOTTOMLEFTY + kTILEBORDER + ( (kTILEWIDTH + kTILEGAP) * Row );
}

-(void)PrintBoard{
    NSLog(@"Board:");
    for(int rank = 4; rank >= 0; rank--) {
        NSLog(@"%d %d %d %d %d",
              boardOcc[rank * 5],
              boardOcc[(rank * 5) + 1],
              boardOcc[(rank * 5) + 2],
              boardOcc[(rank * 5) + 3],
              boardOcc[(rank * 5) + 4]);
    }
}

-(int)GetSquareFromPoint:(CGPoint)point {
    
    [self PrintBoard];
    
    for(int sq = 0; sq < 24; ++sq) {
        if( CGRectContainsPoint([spriteBoard[sq] boundingBox], point) ) {
            for(int currIndex = 0; currIndex < 25; ++currIndex) {
                if(boardOcc[currIndex] == spriteBoard[sq].TileNumber) {
                    NSLog(@"Found Tile On sq %d", currIndex);
                    return currIndex;
                }
            }
        }
    }
    
    return -1;    
}


-(void) registerWithTouchDispatcher {
	[[[CCDirector sharedDirector] touchDispatcher] addTargetedDelegate:self priority:0 swallowsTouches:YES];
}

-(BOOL) ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event {

    CGPoint touchLocation = [self convertTouchToNodeSpace:touch];
    NSLog(@"ccTouchBegan() touchLocation (%0.f,%0.f)", touchLocation.x, touchLocation.y);
    [self GetSquareFromPoint:touchLocation];
    return YES;
}

- (void)ccTouchMoved:(UITouch *)touch withEvent:(UIEvent *)event {
    
    CGPoint touchLocation = [self convertTouchToNodeSpace:touch];
    NSLog(@"ccTouchMoved() touchLocation (%0.f,%0.f)", touchLocation.x, touchLocation.y);
    
}

-(id)init {
    
    self = [super init];
    
    if(self != nil) {
        
        _batchNode = [CCSpriteBatchNode batchNodeWithFile:@"TileSpriteSheet.png"];
        [self addChild:_batchNode];
        
        [[CCSpriteFrameCache sharedSpriteFrameCache] addSpriteFramesWithFile: @"TileSpriteSheet.plist"];
        
        NSString *fileName;
        float x, y;
        bool isRetina = CC_CONTENT_SCALE_FACTOR() == 2.0f ? true : false;
        
               
        for(int i = 0; i < 24; ++i) {
            
            fileName = [NSString stringWithFormat:@"tile%d%@.png", i + 1, isRetina ? @"-ipadhd" : @""];
            //NSLog(@"Filename: %@",fileName);
            spriteBoard[i] = [GameTile spriteWithSpriteFrameName:fileName];
            
            x=(float)[self GetXCoordFromTileCol:Cols[i]];
            y=(float)[self GetYCoordFromTileRow:Rows[i]];
            //NSLog(@"Tile index %i position (%0.f,%0.f) filname %@",i,x,y,fileName);
            
            spriteBoard[i].anchorPoint = ccp(0, 0);
            spriteBoard[i].position = ccp(x, y);
            spriteBoard[i].TileNumber = i;
            [_batchNode addChild:spriteBoard[i] z:1];
            
            boardOcc[i] = i;
            
        }
        
        boardOcc[24] = kEMPTY;        
        [self PrintBoard];
        
        self.isTouchEnabled = YES;
                      
    }   
    
    return self;
}


@end
