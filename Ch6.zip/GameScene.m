//
//  GameScene.m
//  TileTutorial
//
//  Created by ScreenCast on 6/16/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import "GameScene.h"
#import "BackGroundLayer.h"

@implementation GameScene

-(id)init {
    
    self = [super init];
    
    if(self != nil) {
        
        // add layers
        BackGroundLayer *bgLayer = [BackGroundLayer node];
        
        [self addChild:bgLayer z:0];
        
    }
    
    return self;
}

@end
