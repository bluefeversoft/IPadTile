//
//  BackGroundLayer.m
//  TileTutorial
//
//  Created by ScreenCast on 6/16/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import "BackGroundLayer.h"


@implementation BackGroundLayer

-(id)init {
    
    self = [super init];
    
    if(self != nil) {
        
        
    }
    
    return self;
}

-(void) onEnter
{
	[super onEnter];
    
    CGSize size = [[CCDirector sharedDirector] winSize];
    
    NSLog(@"OurSize W:%f H:%f",size.width,size.height);
    
    CCSprite *boardImage = [CCSprite spriteWithFile:@"board.png"];
    boardImage.position = ccp(size.width/2, size.height/2);
    
    [self addChild:boardImage z:0];

}

@end
