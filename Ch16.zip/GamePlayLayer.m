//
//  GamePlayLayer.m
//  TileTutorial
//
//  Created by ScreenCast on 6/19/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import "GamePlayLayer.h"

#define kBOARDBOTTOMLEFTX 160
#define kBOARDBOTTOMLEFTY 32
#define kTILEBORDER 10
#define kTILEGAP 6
#define kTILEWIDTH 130

#define kEMPTY 24

#define UpperLimitY kBOARDBOTTOMLEFTY + kTILEBORDER + (kTILEWIDTH * 5) + kTILEGAP * 4
#define UpperLimitX kBOARDBOTTOMLEFTX + kTILEBORDER + (kTILEWIDTH * 5) + kTILEGAP * 4
#define LowerLimitY kBOARDBOTTOMLEFTY + kTILEBORDER
#define LowerLimitX kBOARDBOTTOMLEFTX + kTILEBORDER

const int Cols[25] = {
    0,1,2,3,4,
    0,1,2,3,4,
    0,1,2,3,4,
    0,1,2,3,4,
    0,1,2,3,4
    
    /*
     5 6 7 8 9
     0 1 2 3 4
     */
};

const int Rows[25] = {
    0,0,0,0,0,
    1,1,1,1,1,
    2,2,2,2,2,
    3,3,3,3,3,
    4,4,4,4,4
};

@implementation GamePlayLayer

-(int)GetXCoordFromTileCol:(int)Col {
    return kBOARDBOTTOMLEFTX + kTILEBORDER + ( (kTILEWIDTH + kTILEGAP) * Col );
}

-(int)GetYCoordFromTileRow:(int)Row {
    return kBOARDBOTTOMLEFTY + kTILEBORDER + ( (kTILEWIDTH + kTILEGAP) * Row );
}

-(void)PrintBoard{
    NSLog(@"Board:");
    for(int rank = 4; rank >= 0; rank--) {
        NSLog(@"%d %d %d %d %d",
              boardOcc[rank * 5],
              boardOcc[(rank * 5) + 1],
              boardOcc[(rank * 5) + 2],
              boardOcc[(rank * 5) + 3],
              boardOcc[(rank * 5) + 4]);
    }
}

-(BOOL)OutOfBoard:(CGPoint)touchPoint{
    if(touchPoint.y > UpperLimitY) return YES;
    else if(touchPoint.y < LowerLimitY) return YES;
    else if(touchPoint.x > UpperLimitX) return YES;
    else if(touchPoint.x < LowerLimitX) return YES;
    
    return NO;
}

-(BOOL)CanMoveToSq:(int)sq fromSq:(int)sqf {

    if(boardOcc[sq] != kEMPTY) return NO;
    
    int diff = sqf - sq;
    
    if(diff < 0) diff *= -1;
    
    if(diff != 5 && diff != 1) {
        return NO;
    }
    
    return YES;
}

-(int)GetBoardSquareFromPoint:(CGPoint)point {
    
    if([self OutOfBoard:point]) {
        return -1;
    }
    
    int x = point.x - kTILEBORDER - kBOARDBOTTOMLEFTX;
    int y = point.y - kTILEBORDER - kBOARDBOTTOMLEFTY;
    
    int totalTileWidth = kTILEWIDTH + kTILEGAP;
    
    int row = y / totalTileWidth;
    int col = x / totalTileWidth;
    
    int sq = row * 5 + col;
    NSLog(@"GetBoardSquareFromPoint:%d",sq);
    
    return sq;
    
}


-(int)GetTileSquareFromPoint:(CGPoint)point {
    
    
    for(int sq = 0; sq < 24; ++sq) {
        if( CGRectContainsPoint([spriteBoard[sq] boundingBox], point) ) {
            for(int currIndex = 0; currIndex < 25; ++currIndex) {
                if(boardOcc[currIndex] == spriteBoard[sq].TileNumber) {
                    NSLog(@"Found Tile On sq %d", currIndex);
                    return currIndex;
                }
            }
        }
    }
    
    return -1;
}

-(void) registerWithTouchDispatcher {
	[[[CCDirector sharedDirector] touchDispatcher] addTargetedDelegate:self priority:0 swallowsTouches:YES];
}

-(BOOL) ccTouchBegan:(UITouch *)touch withEvent:(UIEvent *)event {
    
    CGPoint touchLocation = [self convertTouchToNodeSpace:touch];
    NSLog(@"ccTouchBegan() touchLocation (%0.f,%0.f)", touchLocation.x, touchLocation.y);
    
    if(isAnimating) return NO;
    
    if(CGRectContainsPoint(easyButton.boundingBox, touchLocation)) {
        NSLog(@"Easy pressed");
        return NO;
    }
    
    if(CGRectContainsPoint(hardButton.boundingBox, touchLocation)) {
        NSLog(@"Hard pressed");        return NO;
    }
    
    if(CGRectContainsPoint(resetButton.boundingBox, touchLocation)) {
        NSLog(@"Reset pressed");
        return NO;
    }
    
    if([self OutOfBoard:touchLocation]) {
        NSLog(@"ccTouchBegan() out of board");
        return NO;
    }
    
    DragStartSq = [self GetTileSquareFromPoint:touchLocation];
    
    if(DragStartSq == -1) {
        NSLog(@"ccTouchBegan() DragStartSq -1");
        return NO;
    }
    
    dragCancelled = NO;
    
    return YES;
}

- (void)ccTouchMoved:(UITouch *)touch withEvent:(UIEvent *)event {
    
    if(dragCancelled) {
        NSLog(@"ccTouchMoved() no sq, -1");
        return;
    }
    
    if(isAnimating) return;
    
    CGPoint touchLocation = [self convertTouchToNodeSpace:touch];
    NSLog(@"ccTouchMoved() touchLocation (%0.f,%0.f)", touchLocation.x, touchLocation.y);
    
    if([self OutOfBoard:touchLocation]) {
        NSLog(@"ccTouchMoved() out of board");
        dragCancelled = YES;
    }
    
    int sqt = [self GetBoardSquareFromPoint:touchLocation];
    NSLog(@"Drag from sq %d to %d", DragStartSq, sqt);
    
    if(DragStartSq != sqt) {
        if([self CanMoveToSq:sqt fromSq:DragStartSq]) {
            NSLog(@"Legal!");
            [self ExecuteTileDrag:boardOcc[DragStartSq] SquareFrom:DragStartSq SquareTo:sqt];
            
        } else {
            NSLog(@"ILegal!");
        }
    } 
}

-(void)dragIsFinished {
    isAnimating = NO;
}

-(void)ExecuteTileDrag:(int)TileIndex SquareFrom:(int)sqf SquareTo:(int)sqto {
    
    NSLog(@"Drag from %d to %d tileIndex:%d",sqf,sqto,TileIndex);
    
    float XposTo = (float)[self GetXCoordFromTileCol:Cols[sqto]];
    float YposTo = (float)[self GetYCoordFromTileRow:Rows[sqto]];
    
    CGPoint toPoint = ccp(XposTo, YposTo);
    
    NSLog(@"Action Goes to %0.f,%0.f",toPoint.x, toPoint.y);
    
    float duration = 0.2f;
    isAnimating = YES;
    
    id moveAction = [CCMoveTo actionWithDuration:duration position:toPoint];
    id callDragDone = [CCCallFunc actionWithTarget:self selector:@selector(dragIsFinished)];
    
    CCSprite *selectedTile = spriteBoard[TileIndex];
    [selectedTile runAction: [CCSequence actions: moveAction, callDragDone, nil]];
    
    boardOcc[sqto] = boardOcc[sqf];
    boardOcc[sqf] = kEMPTY;
    
    [self PrintBoard];
}

-(id)init {
    
    self = [super init];
    
    if(self != nil) {
        
        _batchNode = [CCSpriteBatchNode batchNodeWithFile:@"TileSpriteSheet.png"];
        [self addChild:_batchNode];
        
        [[CCSpriteFrameCache sharedSpriteFrameCache] addSpriteFramesWithFile: @"TileSpriteSheet.plist"];
        
        NSString *fileName;
        float x, y;
        bool isRetina = CC_CONTENT_SCALE_FACTOR() == 2.0f ? true : false;
        
        
        for(int i = 0; i < 24; ++i) {
            
            fileName = [NSString stringWithFormat:@"tile%d%@.png", i + 1, isRetina ? @"-ipadhd" : @""];
            //NSLog(@"Filename: %@",fileName);
            spriteBoard[i] = [GameTile spriteWithSpriteFrameName:fileName];
            
            x = (float)[self GetXCoordFromTileCol:Cols[i]];
            y = (float)[self GetYCoordFromTileRow:Rows[i]];
            //NSLog(@"Tile index %i position (%0.f,%0.f) filname %@",i,x,y,fileName);
            
            spriteBoard[i].anchorPoint = ccp(0, 0);
            spriteBoard[i].position = ccp(x, y);
            spriteBoard[i].TileNumber = i;
            [_batchNode addChild:spriteBoard[i] z:1];
            
            boardOcc[i] = i;
            
        }
        
        boardOcc[24] = kEMPTY;
        [self PrintBoard];
        
        hardButton = [CCSprite spriteWithSpriteFrameName:[NSString stringWithFormat:@"HardButton%@.png", isRetina ? @"-ipadhd" : @""]];
        hardButton.anchorPoint = ccp(0,0);
        hardButton.position = ccp(5,50);
        [_batchNode addChild:hardButton z:1];
        
        resetButton = [CCSprite spriteWithSpriteFrameName:[NSString stringWithFormat:@"ResetButton%@.png", isRetina ? @"-ipadhd" : @""]];
        resetButton.anchorPoint = ccp(0,0);
        resetButton.position = ccp(5,669);
        [_batchNode addChild:resetButton z:1];
        
        easyButton = [CCSprite spriteWithSpriteFrameName:[NSString stringWithFormat:@"EasyButton%@.png", isRetina ? @"-ipadhd" : @""]];
        easyButton.anchorPoint = ccp(0,0);
        easyButton.position = ccp(5,110);
        [_batchNode addChild:easyButton z:1];
                        
        self.isTouchEnabled = YES;
        
    }
    
    return self;
}


@end
