//
//  GameTile.h
//  TileTutorial
//
//  Created by ScreenCast on 6/26/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"

@interface GameTile : CCSprite {
    
}

@property(nonatomic) int TileNumber;

@end
