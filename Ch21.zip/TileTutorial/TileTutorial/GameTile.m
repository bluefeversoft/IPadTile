//
//  GameTile.m
//  TileTutorial
//
//  Created by ScreenCast on 6/26/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import "GameTile.h"


@implementation GameTile

@synthesize TileNumber;

@end
