//
//  GamePlayLayer.h
//  TileTutorial
//
//  Created by ScreenCast on 6/19/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "cocos2d.h"
#import "GameTile.h"

@interface GamePlayLayer : CCLayer {
    CCSpriteBatchNode *_batchNode;
    GameTile *spriteBoard[24];    
    bool dragCancelled;
    int boardOcc[25];
    int DragStartSq;
    bool isAnimating;
    bool inGame;
    
    CCSprite *easyButton;
    CCSprite *hardButton;
    CCSprite *resetButton;
    
    CCSprite *winFace;
    
}

@end
