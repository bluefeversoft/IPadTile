//
//  BackGroundLayer.m
//  TileTutorial
//
//  Created by ScreenCast on 6/16/13.
//  Copyright 2013 __MyCompanyName__. All rights reserved.
//

#import "BackGroundLayer.h"


@implementation BackGroundLayer

-(id)init {
    
    self = [super init];
    
    if(self != nil) {
        
        // add images etc.....
        
    }
    
    return self;
}

@end
